<template>
    <button>确定</button>
</template>
<script>
export default {
  name: 'z-button'
}
</script>
<style lang="less">

</style>
